import boto3
import os
import tempfile
import pandas as pd
from io import BytesIO

def lambda_handler(event, context):
    # Initialize boto3 clients
    codecommit = boto3.client("codecommit", region_name=os.environ["AWS_REGION"])
    s3 = boto3.client("s3")
    
    # Environment variables
    repo_name = os.environ.get("REPO_NAME")
    branch_name = os.environ.get("BRANCH_NAME", "mainline")  # Default to "mainline"
    bucket_name = "codeexamplestats"
    csv_file_key = "stats.csv"

    try:
        # Step 1: Retrieve the .stats file content directly from CodeCommit
        file_response = codecommit.get_file(
            repositoryName=repo_name,
            filePath='.stats',  # Specify the path to the .stats file
            commitSpecifier=branch_name
        )
        
        # Parse the .stats file content (assumed to be in JSON format)
        stats_data = eval(file_response['fileContent'].decode("utf-8"))  # Use json.loads for more secure parsing if needed
        
        # Step 2: Fetch the current stats.csv file from S3
        try:
            csv_obj = s3.get_object(Bucket=bucket_name, Key=csv_file_key)
            csv_data = csv_obj['Body'].read()
            df = pd.read_csv(BytesIO(csv_data))
        except s3.exceptions.NoSuchKey:
            # If file doesn't exist, create an empty DataFrame with the required schema
            df = pd.DataFrame(columns=['sdks', 'services', 'examples', 'versions', 
                                       'snippets', 'genai_none', 'genai_some', 'genai_most'])

        # Step 3: Append the new data from .stats file to DataFrame
        new_row = {
            'sdks': stats_data['sdks'],
            'services': stats_data['services'],
            'examples': stats_data['examples'],
            'versions': stats_data['versions'],
            'snippets': stats_data['snippets'],
            'genai_none': stats_data['genai']['none'],
            'genai_some': stats_data['genai']['some'],
            'genai_most': stats_data['genai']['most']
        }
        df = df.append(new_row, ignore_index=True)

        # Step 4: Save the updated DataFrame back to CSV and upload it to S3
        with BytesIO() as output:
            df.to_csv(output, index=False)
            output.seek(0)
            s3.put_object(Bucket=bucket_name, Key=csv_file_key, Body=output.getvalue())
        
        print("Successfully updated stats.csv in S3 with new .stats data.")
    
    except Exception as e:
        print(f"Error occurred: {e}")
        return {"statusCode": 500, "body": "Failed to update stats.csv."}

    return {"statusCode": 200, "body": "stats.csv updated successfully in S3."}
